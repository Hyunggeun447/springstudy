package hello2.helloClonespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloCloneSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
